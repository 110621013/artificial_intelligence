import json
import argparse
from collections import defaultdict
from copy import deepcopy


def course_schedule_solver() -> list:
    global COURSE_ORDER
    order = COURSE_ORDER
    # BEGIN_YOUR_CODE
    # 如果有解，需要回傳順序的結果
    raise Exception("Not implemented yet")
    # END_YOUR_CODE
    return []


if __name__ == '__main__':
    COURSE_ORDER = []

    parser = argparse.ArgumentParser()
    parser.add_argument('--course_file_path', '-f', type=str, default='q2_sample_input.json')

    args = parser.parse_args()
    with open(args.course_file_path, "r+") as fs:
        course_schedule_info = json.load(fs)
        numCourses = course_schedule_info['numCourses']
        prerequisites = course_schedule_info['prerequisites']

    COURSE_ORDER = [-1 for x in range(numCourses)]
    course_order = course_schedule_solver()

    print("COURSE ORDER:")
    print(course_order)

    result_dict = {
        "result": course_order
    }

    with open('course_schedule_result.json', 'w+') as fs:
        fs.write(json.dumps(result_dict, indent=4))
